const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const dotenv = require('dotenv');
const mysql = require('mysql2/promise');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

const DB_HOST = process.env.DB_HOST || '127.0.0.1';
const DB_PORT = process.env.DB_PORT || 3306;
const DB_USER = process.env.DB_USER || 'root';
const DB_PASS = process.env.DB_PASS || '';
const DB_NAME = process.env.DB_NAME || 'swu_project';

let pool;

async function initDb() {
	pool = await mysql.createPool({
		host: DB_HOST,
		port: DB_PORT,
		user: DB_USER,
		password: DB_PASS,
		waitForConnections: true,
		connectionLimit: 10,
		queueLimit: 0
	});

	// create database if not exists
	await pool.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\``);
	await pool.query(`USE \`${DB_NAME}\``);

	// create users table
	await pool.query(`
		CREATE TABLE IF NOT EXISTS users (
			id VARCHAR(50) PRIMARY KEY,
			name VARCHAR(255) NOT NULL,
			qualification VARCHAR(255),
			email VARCHAR(255) NOT NULL UNIQUE,
			experience VARCHAR(1024),
			password VARCHAR(255) NOT NULL,
			createdAt DATETIME NOT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
	`);

	// create assessments table
	await pool.query(`
		CREATE TABLE IF NOT EXISTS assessments (
			id VARCHAR(50) PRIMARY KEY,
			userId VARCHAR(50) NOT NULL,
			response1 INT NOT NULL,
			response2 INT NOT NULL,
			response3 INT NOT NULL,
			response4 INT NOT NULL,
			response5 INT NOT NULL,
			response6 INT NOT NULL,
			response7 INT NOT NULL,
			response8 INT NOT NULL,
			response9 INT NOT NULL,
			response10 INT NOT NULL,
			response11 INT NOT NULL,
			response12 INT NOT NULL,
			submittedAt DATETIME NOT NULL,
			FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
			INDEX idx_userId (userId)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
	`);

	// create evaluations table for Yes/No evaluation form
	await pool.query(`
		CREATE TABLE IF NOT EXISTS evaluations (
			id VARCHAR(50) PRIMARY KEY,
			userId VARCHAR(50) NOT NULL,
			question1 TINYINT(1) NOT NULL,
			question2 TINYINT(1) NOT NULL,
			question3 TINYINT(1) NOT NULL,
			question4 TINYINT(1) NOT NULL,
			question5 TINYINT(1) NOT NULL,
			question6 TINYINT(1) NOT NULL,
			question7 TINYINT(1) NOT NULL,
			question8 TINYINT(1) NOT NULL,
			question9 TINYINT(1) NOT NULL,
			question10 TINYINT(1) NOT NULL,
			remarks TEXT,
			submittedAt DATETIME NOT NULL,
			FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
			INDEX idx_userId (userId)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
	`);
	
	// Add remarks column if it doesn't exist (for existing tables)
	try {
		await pool.query('ALTER TABLE evaluations ADD COLUMN remarks TEXT');
	} catch (err) {
		// Column already exists, ignore error
	}
}

function authMiddleware(req, res, next) {
	const header = req.headers.authorization;
	if (!header) return res.status(401).json({ error: 'Missing authorization' });
	const parts = header.split(' ');
	if (parts.length !== 2) return res.status(401).json({ error: 'Invalid authorization' });
	const token = parts[1];
	try {
		const payload = jwt.verify(token, JWT_SECRET);
		req.user = payload;
		// For admin account, ensure isAdmin is set
		if (payload.id === 'admin') {
			req.user.isAdmin = true;
		}
		next();
	} catch (err) {
		return res.status(401).json({ error: 'Invalid token' });
	}
}

app.post('/api/register', async (req, res) => {
	try {
		const { name, qualification, email, experience, password } = req.body;
		if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });
		const [rows] = await pool.query('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
		if (rows.length) return res.status(400).json({ error: 'Email already registered' });
		const hashed = await bcrypt.hash(password, 10);
		const id = Date.now().toString();
		const createdAt = new Date();
		await pool.query(
			'INSERT INTO users (id, name, qualification, email, experience, password, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)',
			[id, name, qualification || '', email.toLowerCase(), experience || '', hashed, createdAt]
		);
		const token = jwt.sign({ id, email: email.toLowerCase() }, JWT_SECRET, { expiresIn: '7d' });
		res.json({ token, user: { id, name, email: email.toLowerCase(), qualification: qualification || '', experience: experience || '' } });
	} catch (err) {
		console.error(err);
		res.status(500).json({ error: 'Server error' });
	}
});

app.post('/api/login', async (req, res) => {
	try {
		const { email, password } = req.body;
		if (!email || !password) return res.status(400).json({ error: 'email and password required' });
		
		// Check for hardcoded admin account
		if (email.toLowerCase() === 'admin@venu.com' && password === 'admin1234') {
			const adminUser = {
				id: 'admin',
				name: 'Admin',
				email: 'admin@venu.com',
				qualification: 'Administrator',
				experience: '',
				isAdmin: true
			};
			const token = jwt.sign({ id: adminUser.id, email: adminUser.email, isAdmin: true }, JWT_SECRET, { expiresIn: '7d' });
			return res.json({ token, user: adminUser });
		}
		
		const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email.toLowerCase()]);
		const user = rows[0];
		if (!user) return res.status(400).json({ error: 'Invalid credentials' });
		const ok = await bcrypt.compare(password, user.password);
		if (!ok) return res.status(400).json({ error: 'Invalid credentials' });
		const token = jwt.sign({ id: user.id, email: user.email, isAdmin: false }, JWT_SECRET, { expiresIn: '7d' });
		res.json({ token, user: { id: user.id, name: user.name, email: user.email, qualification: user.qualification, experience: user.experience, isAdmin: false } });
	} catch (err) {
		console.error(err);
		res.status(500).json({ error: 'Server error' });
	}
});

app.get('/api/me', authMiddleware, async (req, res) => {
	try {
		// Check if admin account
		if (req.user.id === 'admin') {
			return res.json({
				id: 'admin',
				name: 'Admin',
				email: 'admin@venu.com',
				qualification: 'Administrator',
				experience: '',
				isAdmin: true
			});
		}
		
		const [rows] = await pool.query('SELECT id, name, email, qualification, experience FROM users WHERE id = ?', [req.user.id]);
		const user = rows[0];
		if (!user) return res.status(404).json({ error: 'User not found' });
		res.json({ ...user, isAdmin: false });
	} catch (err) {
		console.error(err);
		res.status(500).json({ error: 'Server error' });
	}
});

app.post('/api/assessment/submit', authMiddleware, async (req, res) => {
	try {
		const { userId, responses } = req.body;
		
		if (!userId || !responses) {
			return res.status(400).json({ error: 'userId and responses are required' });
		}

		if (userId !== req.user.id) {
			return res.status(403).json({ error: 'Unauthorized' });
		}

		// Validate all 12 responses are present
		const requiredResponses = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
		for (const qId of requiredResponses) {
			if (!responses[qId] || responses[qId] < 1 || responses[qId] > 5) {
				return res.status(400).json({ error: `Invalid or missing response for question ${qId}` });
			}
		}

		// Check if user already submitted an assessment
		const [existing] = await pool.query('SELECT id FROM assessments WHERE userId = ?', [userId]);
		
		const id = existing.length > 0 ? existing[0].id : Date.now().toString();
		const submittedAt = new Date();

		if (existing.length > 0) {
			// Update existing assessment
			await pool.query(
				`UPDATE assessments SET 
					response1 = ?, response2 = ?, response3 = ?, response4 = ?,
					response5 = ?, response6 = ?, response7 = ?, response8 = ?,
					response9 = ?, response10 = ?, response11 = ?, response12 = ?,
					submittedAt = ?
					WHERE userId = ?`,
				[
					responses[1], responses[2], responses[3], responses[4],
					responses[5], responses[6], responses[7], responses[8],
					responses[9], responses[10], responses[11], responses[12],
					submittedAt, userId
				]
			);
		} else {
			// Insert new assessment
			await pool.query(
				`INSERT INTO assessments 
					(id, userId, response1, response2, response3, response4, response5, response6,
					 response7, response8, response9, response10, response11, response12, submittedAt)
					VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
				[
					id, userId,
					responses[1], responses[2], responses[3], responses[4],
					responses[5], responses[6], responses[7], responses[8],
					responses[9], responses[10], responses[11], responses[12],
					submittedAt
				]
			);
		}

		res.json({ 
			success: true, 
			message: 'Assessment submitted successfully',
			id,
			submittedAt
		});
	} catch (err) {
		console.error(err);
		res.status(500).json({ error: 'Server error' });
	}
});

app.get('/api/assessment/:userId', authMiddleware, async (req, res) => {
	try {
		const { userId } = req.params;
		
		if (userId !== req.user.id) {
			return res.status(403).json({ error: 'Unauthorized' });
		}

		const [rows] = await pool.query(
			'SELECT * FROM assessments WHERE userId = ? ORDER BY submittedAt DESC LIMIT 1',
			[userId]
		);

		if (rows.length === 0) {
			return res.status(404).json({ error: 'Assessment not found' });
		}

		const assessment = rows[0];
		const responses = {
			1: assessment.response1,
			2: assessment.response2,
			3: assessment.response3,
			4: assessment.response4,
			5: assessment.response5,
			6: assessment.response6,
			7: assessment.response7,
			8: assessment.response8,
			9: assessment.response9,
			10: assessment.response10,
			11: assessment.response11,
			12: assessment.response12
		};

		res.json({
			id: assessment.id,
			userId: assessment.userId,
			responses,
			submittedAt: assessment.submittedAt
		});
	} catch (err) {
		console.error(err);
		res.status(500).json({ error: 'Server error' });
	}
});

app.post('/api/evaluation/submit', authMiddleware, async (req, res) => {
	try {
		const { userId, responses, remarks } = req.body;
		
		if (!userId || !responses) {
			return res.status(400).json({ error: 'userId and responses are required' });
		}

		if (userId !== req.user.id) {
			return res.status(403).json({ error: 'Unauthorized' });
		}

		// Validate all 10 responses are present (1 for Yes, 0 for No)
		const requiredQuestions = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
		for (const qId of requiredQuestions) {
			if (responses[qId] === undefined || responses[qId] === null) {
				return res.status(400).json({ error: `Missing response for question ${qId}` });
			}
			if (responses[qId] !== 0 && responses[qId] !== 1) {
				return res.status(400).json({ error: `Invalid response for question ${qId}. Must be 0 (No) or 1 (Yes)` });
			}
		}

		// Check if user already submitted an evaluation
		const [existing] = await pool.query('SELECT id FROM evaluations WHERE userId = ?', [userId]);
		
		if (existing.length > 0) {
			return res.status(400).json({ error: 'You have already submitted your evaluation. Only one submission is allowed.' });
		}

		const id = Date.now().toString();
		const submittedAt = new Date();

		// Insert new evaluation
		await pool.query(
			`INSERT INTO evaluations 
				(id, userId, question1, question2, question3, question4, question5, question6,
				 question7, question8, question9, question10, remarks, submittedAt)
				VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
			[
				id, userId,
				responses[1], responses[2], responses[3], responses[4],
				responses[5], responses[6], responses[7], responses[8],
				responses[9], responses[10],
				remarks || '',
				submittedAt
			]
		);

		res.json({ 
			success: true, 
			message: 'Evaluation submitted successfully',
			id,
			submittedAt
		});
	} catch (err) {
		console.error(err);
		res.status(500).json({ error: 'Server error' });
	}
});

app.get('/api/evaluation/:userId', authMiddleware, async (req, res) => {
	try {
		const { userId } = req.params;
		
		if (userId !== req.user.id && !req.user.isAdmin) {
			return res.status(403).json({ error: 'Unauthorized' });
		}

		const [rows] = await pool.query(
			'SELECT * FROM evaluations WHERE userId = ? ORDER BY submittedAt DESC LIMIT 1',
			[userId]
		);

		if (rows.length === 0) {
			return res.status(404).json({ error: 'Evaluation not found' });
		}

		const evaluation = rows[0];
		const responses = {
			1: evaluation.question1,
			2: evaluation.question2,
			3: evaluation.question3,
			4: evaluation.question4,
			5: evaluation.question5,
			6: evaluation.question6,
			7: evaluation.question7,
			8: evaluation.question8,
			9: evaluation.question9,
			10: evaluation.question10
		};

		res.json({
			id: evaluation.id,
			userId: evaluation.userId,
			responses,
			remarks: evaluation.remarks || '',
			submittedAt: evaluation.submittedAt
		});
	} catch (err) {
		console.error(err);
		res.status(500).json({ error: 'Server error' });
	}
});

app.get('/api/admin/evaluations', authMiddleware, async (req, res) => {
	try {
		// Check if user is admin
		if (!req.user.isAdmin && req.user.id !== 'admin') {
			return res.status(403).json({ error: 'Admin access required' });
		}

		// Get all evaluations with user information
		const [rows] = await pool.query(`
			SELECT 
				e.*,
				u.name as userName,
				u.email as userEmail,
				u.qualification as userQualification,
				u.experience as userExperience
			FROM evaluations e
			INNER JOIN users u ON e.userId = u.id
			ORDER BY e.submittedAt DESC
		`);

		const evaluations = rows.map(evaluation => ({
			id: evaluation.id,
			userId: evaluation.userId,
			userName: evaluation.userName,
			userEmail: evaluation.userEmail,
			userQualification: evaluation.userQualification || '',
			userExperience: evaluation.userExperience || '',
			responses: {
				1: evaluation.question1,
				2: evaluation.question2,
				3: evaluation.question3,
				4: evaluation.question4,
				5: evaluation.question5,
				6: evaluation.question6,
				7: evaluation.question7,
				8: evaluation.question8,
				9: evaluation.question9,
				10: evaluation.question10
			},
			remarks: evaluation.remarks || '',
			submittedAt: evaluation.submittedAt
		}));

		res.json({ evaluations });
	} catch (err) {
		console.error(err);
		res.status(500).json({ error: 'Server error' });
	}
});

const PORT = process.env.PORT || 4000;
initDb().then(() => {
	app.listen(PORT, () => console.log(`Auth API running on http://localhost:${PORT}`));
}).catch(err => {
	console.error('Failed to initialize database', err);
	process.exit(1);
});
